import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    user: null,
    apiKey: null
}

export const userSlice = createSlice({
    name: "user",
    initialState,
    reducers: {
        loginUser: (state, action) => {
            //immer para estados inmutables
            return action.payload;
        },
        logoutUser: (state, action) => {
            return { user: null, apiKey: null }
        }
    }
});

// Guardo las "acciones" que quiero exportar en este caso las "funciones" del reducers
export const { loginUser, logoutUser } = userSlice.actions;
// Tambien debo exportar la propiedad reducer generica para que las reconozca
export default userSlice.reducer;