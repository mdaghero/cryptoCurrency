import { createSlice } from "@reduxjs/toolkit";


const initialState = {
    currencies: []
}

export const currenciesSlice = createSlice({
    name: "currencies",
    initialState,
    reducers: {
        storeCurrencies: (state, action) => {
           return {...state, currencies: action.payload}
        }
    }

})

export const { storeCurrencies } = currenciesSlice.actions;
export default currenciesSlice.reducer;