import { createSlice } from "@reduxjs/toolkit";


const initialState = {
    transactions: []
}

export const transactionsSlice = createSlice({
    name: "transactions",
    initialState,
    reducers: {
        storeTransactions: (state, action) => {
            return {...state, transactions: action.payload}
        }
    }

})

export const { storeTransactions } = transactionsSlice.actions;
export default transactionsSlice.reducer;