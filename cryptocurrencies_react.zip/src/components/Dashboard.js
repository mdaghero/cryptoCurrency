import React from 'react'
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { storeTransactions } from '../features/transactionsSlice';
import { useNavigate } from 'react-router-dom';
import CreateTransaction from './componentsDash/CreateTransaction';
import Graphs from './componentsDash/Graphs'
import Transactions from './componentsDash/Transactions';

const Dashboard = () => {

  let navigate = useNavigate();
  const urlGetTransactions = 'https://crypto.develotion.com/transacciones.php?idUsuario=1';

  const dispatch = useDispatch();
  // aca voy a usar un selectyor porque este mismo componente va a guardar pero
  // tambien tiene que listar, entonces accedo al store >> transactions >> transactions
  const transactions = useSelector(state => state.transactions.transactions);


  useEffect(() => {

    if(localStorage.getItem('userId') === "" || localStorage.getItem('userId') === null){
      navigate("/");
    }

  }, [])

  return (
    <div>
     
      <Transactions/>
      <CreateTransaction/>
      
      <Graphs/>
    </div>
  )
}

export default Dashboard