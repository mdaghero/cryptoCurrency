import React from 'react'
import { useRef, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';



const Registro = () => {

    const urlDepts = 'https://crypto.develotion.com/departamentos.php';
    const urlCities = 'https://crypto.develotion.com/ciudades.php?idDepartamento=';
    const urlRegisterUser = 'https://crypto.develotion.com/usuarios.php'; 

    const userNameText = useRef(null);
    const passwordText = useRef(null);
    let idDeptSelected = null;
    let idCitySelected = null;

    const [departments, setDepartments] = useState([]);
    const [idDept, setIdDept] = useState(null);
    const [cities, setCities] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();
    

    useEffect(() => {

        fetch(urlDepts)
            .then(response => response.json())
            .then(data => {
                console.log(data);
                setLoading(false);
                setDepartments(data.departamentos);
                console.log(data.departamentos);
            })
    }, []);


    const getCityId = event => {
        idCitySelected = event.target.value;
        console.log(idCitySelected);
    }

    const handleChange = event => {
        idDeptSelected = event.target.value;
        console.log(idDeptSelected);
        setIdDept(idDeptSelected);

        fetch(urlCities + idDeptSelected)
            .then(response => response.json())
            .then(data2 => {
                setLoading(false);
                setCities(data2.ciudades);
                console.log(data2.ciudades);
            })
    };

    console.log(cities);

    const registerData = evt => {
        let userName = userNameText.current.value;
        let password = passwordText.current.value;

        console.log(idDept);

        let newUser = {
            "usuario": userName,
            "password": password,
            "idDepartamento": idDept,
            "idCiudad": idCitySelected
        }
        console.log(newUser);

        fetch(urlRegisterUser, {
            method: 'POST',
            body: JSON.stringify(newUser),
            headers: {
                'Content-Type': 'application/json',
            },
        })
            .then(response => {
                if (response.status === 200) {
                  return response.json();
                } else {
                  console.log(response);
                  return Promise.reject(response);
                }
              })
            .then((data) => {
                console.log(data);
                localStorage.setItem("userId", data.id);
                localStorage.setItem("apiKey", data.apiKey);
                navigate("/Dashboard");
            })
            .catch((error) => alert(`Error de Registro: ${error.statusText}`));

    }

    return (
        <div className="registration">

            <label htmlFor="txtUserNameReg">Nombre de Usuario: </label>
            <input ref={userNameText} type="text" name="txtUserNameReg" id="txtUserNameReg" />
            <hr />
            <label htmlFor="txtPassReg">Contraseña: </label>
            <input ref={passwordText} type="text" name="txtPassReg" id="txtPassReg" />
            <hr />
            <label htmlFor="slcDepartaments">Seleccione Departamento: </label>
            <select onChange={handleChange} name="slcDepartaments" id="idDepto">
                <option value=""> Seleccione un departamento </option>
                {departments.map(option => (
                    <option key={option.id} value={option.id}> {option.nombre} </option>
                ))}
            </select>
            <hr />

            <select onChange={getCityId} name="slcCities" id="idCity">
                <option value=""> Seleccione una ciudad </option>
                {cities.map(option => (
                    <option key={option.id} value={option.id}> {option.nombre} </option>
                ))}
            </select>
            <hr />
            <input type="button" value="Registrar" onClick={registerData} />

            {(loading) ? <h4> Cargando... </h4> : <p></p>}

        </div>

    )
}

export default Registro


