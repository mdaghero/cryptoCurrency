import React from 'react'

const CurrencyGraph = () => {
  return (
    <div>
        <h2>GRAFICO DE COTIZACION DE MONEDA </h2>
    </div>
  )
}

export default CurrencyGraph