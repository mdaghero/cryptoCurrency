import React from 'react'
import PurchasesGraph from './PurchasesGraph'
import SalesGraph from './SalesGraph'
import CurrencyGraph from './CurrencyGraph'
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Graphs = () => {

    const navigate = useNavigate();

    useEffect(() => {

        if(localStorage.getItem('userId') === "" || localStorage.getItem('userId') === null){
            navigate("/");
        }    




    }, [])

    return (
        <div>
            <PurchasesGraph/>
            <SalesGraph/>
            <CurrencyGraph/>
        </div>
    )
}

export default Graphs