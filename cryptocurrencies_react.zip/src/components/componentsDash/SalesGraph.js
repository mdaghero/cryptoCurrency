import React from 'react'
import { Link } from 'react-router-dom';

const SalesGraph = () => {
    return (
        <div>
            <h2>GRAFICO DE VENTAS DE MONEDA </h2>

            <Link to="/Dashboard"> Back to Dashboard </Link>

        </div>
    )
}

export default SalesGraph