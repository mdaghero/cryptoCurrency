import React from 'react'
import { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';


const Login = () => {

  const urlLogin = 'https://crypto.develotion.com/login.php';

  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");

  const navigate = useNavigate();

  const access = event => {

    let userLog = {
      "usuario": user,
      "password": pass
    }

    fetch(urlLogin, {
      method: 'POST',
      body: JSON.stringify(userLog),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8',
      },
    })
      .then(response => {
        if (response.status === 200) {
          return response.json();
        } else {
          console.log(response);
          return Promise.reject(response);
        }
      })
      .then(data => {
        console.log(data);
        localStorage.setItem("userId", data.id);
        localStorage.setItem("apiKey", data.apiKey);
        navigate("/Dashboard");
      })
      .catch((error) => alert(`Error de Login: ${error.statusText}`));
    
  }

  const onChangeUser = (evt) => { setUser(evt.target.value) };
  const onChangePass = (evt) => { setPass(evt.target.value) };

  return (
    <div>

      <label htmlFor="txtUsername">Usuario: </label>
      <input onChange={onChangeUser} value={user} type="text" id="txtUsername" />
      <br />
      <label htmlFor="txtPass">Contraseña: </label>
      <input onChange={onChangePass} value={pass} type="password" id="txtPass" />
      <br />

      <input type="button" value="Login" onClick={access} disabled={user.length === 0 || pass.length === 0}/>

    </div>
  )
}

export default Login