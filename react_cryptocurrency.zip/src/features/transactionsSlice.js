import { createSlice } from "@reduxjs/toolkit";


const initialState = {
    transactions: []
}

export const transactionsSlice = createSlice({
    name: "transactions",
    initialState,
    reducers: {
        getTransactions: (state, action) => {
            return {...state, transactions: action.payload};
        }, 
        addTransaction: (state, action) => {
            state.transactions.push(action.payload);
        }
    }

})

export const { addTransaction, getTransactions } = transactionsSlice.actions;
export default transactionsSlice.reducer;