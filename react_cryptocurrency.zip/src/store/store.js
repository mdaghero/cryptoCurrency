import { configureStore } from "@reduxjs/toolkit";
import transactionsReducer from '../features/transactionsSlice';
import currenciesReducer from '../features/currenciesSlice';

export const store = configureStore({
    reducer: {
        transactions: transactionsReducer,
        currencies: currenciesReducer

    }
});