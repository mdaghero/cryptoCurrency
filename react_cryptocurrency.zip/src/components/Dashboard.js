import React from 'react'
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import CreateTransaction from './componentsDash/CreateTransaction';
import Graphs from './componentsDash/Graphs'
import Transactions from './componentsDash/Transactions';
import Investments from './componentsDash/Investments';
import AIntelligence from './componentsDash/AIntelligence';

const Dashboard = () => {

  let navigate = useNavigate();
  

  useEffect(() => {

    if(localStorage.getItem('userId') === "" || localStorage.getItem('userId') === null){
      navigate("/");
    }

  }, [])

  return (
    <div>
      <Transactions/>
      <CreateTransaction/>
      <Investments/>
      <AIntelligence/>
      <Graphs/>
    </div>
  )
}

export default Dashboard