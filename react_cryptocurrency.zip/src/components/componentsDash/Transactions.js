import React from 'react'
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getTransactions } from '../../features/transactionsSlice';
import { useNavigate } from 'react-router-dom';


const Transactions = () => {

    const urlTransactions = 'https://crypto.develotion.com/transacciones.php?idUsuario=';

    
    const navigate = useNavigate();
    const transactions = useSelector(state => state.transactions.transactions);
    const dispatch = useDispatch();
    const [loading, setLoading] = useState(true);


    useEffect(() => {

        let userId = localStorage.getItem('userId');

        if (userId === null || userId === "") {
            navigate("/");
        }

        fetch(urlTransactions + userId, {
            method: 'GET',
            headers: {
                'apikey': localStorage.getItem('apiKey'),
                'Content-Type': 'application/json; charset=UTF-8',
            },
        })
            .then(response => {
                if (response.status === 200) {
                    return response.json();
                } else {
                    return Promise.reject(response);
                }
            })
            .then(data => {
                console.log(data);
                setLoading(false);
                dispatch(getTransactions(data.transacciones));
            })

    }, [])


    console.log(transactions);

    return (
        <div>
            <h4> LISTADO DE TRANSACCIONES </h4>

            <h6> MONEDA | TIPO OPERACION | CANTIDAD | VALOR ACTUAL </h6>
            {(loading) ? <p>Cargando las transacciones...</p> : transactions.map(tran => <p key={tran.id}>|   {tran.moneda}   |   {tran.tipo_operacion}   |   {tran.cantidad}   |   {tran.valor_actual}</p> )}

        </div>
    )
}

export default Transactions