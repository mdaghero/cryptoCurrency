import React from 'react'
import { Link } from 'react-router-dom';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { useEffect, useState } from 'react'
import { useSelector } from 'react-redux';

ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend
);

const SalesGraph = () => {

    const transactions = useSelector(state => state.transactions.transactions)



    return (
        <div>
            <h4>GRAFICO DE VENTAS DE MONEDA </h4>

            <Link to="/Dashboard"> Back to Dashboard </Link>


            <Bar options={{
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Montos vendidos por moneda',
                    },
                },
            }} data={{
                labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
                datasets: [
                    {
                        label: 'Dataset 1',
                        data: [1, 2, 4, 5, 7, 12, 89],
                        backgroundColor: 'rgba(50, 118, 92, 0.5)',
                    }
                ],
            }} />

        </div>
    )
}

export default SalesGraph

