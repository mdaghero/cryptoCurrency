import React from 'react'
import { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getCurrencies } from '../../features/currenciesSlice';
import { useNavigate } from 'react-router-dom';
import { transactionsSlice, currenciesSlice } from '../../features/transactionsSlice';

const AIntelligence = () => {

    const transactions = useSelector(state => state.transactions.transactions);
    const urlCurs = 'https://crypto.develotion.com/monedas.php';

    const currencies = useSelector(state => state.currencies.currencies);
    const [suggestion, setSuggestion] = useState(null);
    const [currencyName, setCurrencyName] = useState("");

    const dispatch = useDispatch();
    const navigate = useNavigate();
    
    useEffect(() => {

        if(localStorage.getItem('userId') === "" || localStorage.getItem('userId') === null){
            navigate("/");
        }

        const interval = setInterval(() => {

            fetch(urlCurs, {
                method: 'GET',
                headers: {
                    'apikey': localStorage.getItem('apiKey'),
                    'Content-Type': 'application/json; charset=UTF-8',
                },
            })
                .then(response => {
                    if (response.status === 200) {
                      return response.json();
                    } else {
                      return Promise.reject(response);
                    }
                })
                .then(data => {
                    dispatch(getCurrencies(data.monedas));
                })

        }, 30000); 


        if(transactions.length > 0) {
            const lastTransaction = transactions[transactions.length -1];
            
            const currency = currencies.find(currency => currency.id === lastTransaction.moneda) 
    
            if(lastTransaction.valor_actual < currency.cotizacion){
                setSuggestion('comprar');
                setCurrencyName(currency.nombre);
            } else if (lastTransaction.valor_actual > currency.cotizacion){
                setSuggestion('vender');
                setCurrencyName(currency.nombre);
            }
        }

        console.log(currencies);
       
        return () => clearInterval(interval);
    }, [transactions, currencies])

    return (
        <div>                                        
            {transactions.length > 0 && <h4> Sugerencia: Es un buen momento para {suggestion} la moneda {currencyName} </h4>}
        </div>
    )
}

export default AIntelligence




/* const transPerCur = transactions.reduce((group, tran) =>{
    const {moneda} = tran;
    group [moneda] = [];
    group[moneda].push(tran);
    return group;
}, []); */



/* transPerCur.forEach(element => {
    curs.forEach(cur => {
        if(element.tipo_operacion === 1){
            if(element.moneda === cur.id && cur.cotizacion > element.valor_actual){
                setFlagNow(true);
                setCurrencyName(curs.nombre);
            }
        } else if (element.tipo_operacion === 2){
            if(element.moneda === cur.id && cur.cotizacion < element.valor_actual){
                setFlagNow(true);
                setCurrencyName(cur.nombre);
            }
        }
    })

}); */