import React from 'react'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { useEffect, useState } from 'react'
import { useSelector } from 'react-redux';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const CurrencyGraph = () => {
  const transactions = useSelector(state => state.transactions.transactions)
  const currencies = useSelector(state => state.currencies.currencies)

  const [graphShow, setGraphShow] = useState(false);

  const [selectedCurrency, setSelectedCurrency] = useState(null);
  const [transactionsPerCurrency, setTransactionsPerCurrency] = useState(null);
  const [transactionsCurrencies, setTransactionsCurrencies] = useState([])

  useEffect(() => {

    const transactionsPerCurrency = {};
    transactions.forEach(transaction => {
      if (transactionsPerCurrency[transaction.moneda] == null) {
        transactionsPerCurrency[transaction.moneda] = [transaction.valor_actual];
      } else {
        transactionsPerCurrency[transaction.moneda].push(transaction.valor_actual);
      }
    });

    setTransactionsPerCurrency(transactionsPerCurrency);

    const transactionsCurrencies = Object.keys(transactionsPerCurrency).map(currencyId => {
      return currencies.find(currency => currency.id == currencyId)
    });

    setTransactionsCurrencies(transactionsCurrencies)

  }, [transactions, currencies])


  const handleChange = evt => {
    const currencyId = Number(evt.target.value);
    const currency = currencies.find(currency => currency.id === currencyId)
    setSelectedCurrency(currency);
  }

  const printGraph = () => {
    setGraphShow(true);
  }


  return (

    <div>

      <h4>GRAFICO DE COTIZACION DE MONEDA </h4>

      <label htmlFor="slcCurrency">Cotizaciones de la moneda: </label>
      <select onChange={handleChange} name="slcCurrency" id="slcCurrency">
        <option value=""> Seleccione una moneda </option>
        {transactionsCurrencies.map(currency => (
          <option key={currency.id} value={currency.id}> {currency.nombre} </option>
        ))}
      </select>
      <hr />

      <input type="button" value="Ver Gráfica" onClick={printGraph} />

      {graphShow && <Bar options={{
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
          },
          title: {
            display: true,
            text: 'Montos comprados por moneda',
          },
        },
      }} data={{
        labels: transactionsPerCurrency[selectedCurrency.id].map(() => selectedCurrency.nombre),
        datasets: [
          {
            label: 'Dataset 1',
            data: transactionsPerCurrency[selectedCurrency.id],
            backgroundColor: 'rgba(30, 99, 162, 0.5)',
          }
        ],
      }} />}


    </div>
  )
}

export default CurrencyGraph