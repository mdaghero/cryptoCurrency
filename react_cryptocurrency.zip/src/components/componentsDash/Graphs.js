import React from 'react'
import PurchasesGraph from './InvestmentsGraph'
import SalesGraph from './SalesGraph'
import CurrencyGraph from './CurrencyGraph'
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Graphs = () => {

    const navigate = useNavigate();

    useEffect(() => {

        if(localStorage.getItem('userId') === "" || localStorage.getItem('userId') === null){
            navigate("/");
        }    


    }, [])

    return (
        <div>
            <PurchasesGraph operation={1}/>
            <PurchasesGraph operation={2}/>
            <CurrencyGraph/>
        </div>
    )
}

export default Graphs