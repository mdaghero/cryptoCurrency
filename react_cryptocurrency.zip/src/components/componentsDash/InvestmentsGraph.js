import React from 'react'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { useEffect, useState } from 'react'
import { useSelector } from 'react-redux';


ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const PurchasesGraph = ({operation}) => {

  const transactions = useSelector(state => state.transactions.transactions)
  const currencies = useSelector(state => state.currencies.currencies)
  const [currencyLabels, setCurrencyLabels ] = useState([]);
  const [totals, setTotals ] = useState([]);


  useEffect(() => {

    const purchases = transactions.filter(transaction => transaction.tipo_operacion === operation);

    const obj = {};
    purchases.forEach(transaction => {
      
      const totalInvest = transaction.valor_actual * transaction.cantidad
      if(obj[transaction.moneda] == null){
        obj[transaction.moneda] = totalInvest;
      }else{
        obj[transaction.moneda] += totalInvest;
      }
    });

    const labels = Object.keys(obj).map(currencyId => {
      const currency = currencies.find(currency => currency.id === Number(currencyId))
      return currency.nombre;
    });
    setCurrencyLabels(labels);
    
    const totals = Object.values(obj);
    setTotals(totals);


  }, [transactions, currencies])


  return (
    <div>
      <h4>GRAFICO DE {operation === 1 ? "COMPRA" : "VENTA"} DE MONEDA </h4>

      <Bar options={{
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
          },
        },
      }} data={{
        labels: currencyLabels,
        datasets: [
          {
            label: 'Moneda',
            data: totals,
            backgroundColor: operation === 1 ? 'rgba(255, 99, 132, 0.5)' : 'rgba(50, 118, 92, 0.5)',
          },

        ],
      }} />
    </div>
  )
}

export default PurchasesGraph



