import React from 'react'
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { transactionsSlice, getTransactions } from '../../features/transactionsSlice';

const Investments = () => {


    const transacts = useSelector(state => state.transactions.transactions);
    const [balance, setBalance] = useState(0);

    console.log(transacts); 

    useEffect(() => {

        let totalInvest = 0;
        transacts.forEach(tran => {
            let num = tran.valor_actual * tran.cantidad;
            if (tran.tipo_operacion == 1){
                num = num * (-1);   
            }
            totalInvest = totalInvest + num;
        });

        setBalance(totalInvest);

    }, [transacts])


    return (

        <div>
            <h4> MONTO FINAL DE INVERSIONES </h4>
            <label htmlFor="txtTotInvest" >Total inversión: </label>
            <input type="text" name="txtTotInvest" id="txtTotInvest" value={balance} readOnly={true} />
            <hr />

        </div>
    )
}

export default Investments







/* const purchases = () => {
    let trans = transacts.filter(tran => tran.tipo_operacion === 1)
    let totPurs = trans.map(pur => pur.cantidad * pur.valor_actual);
    let tot = 0;
    for (let i = 0; i < totPurs.length; i++) {
        let amount = totPurs[i];
        tot.sum(amount);
    }
    return tot;
}

purchases();
const sales = () => {
    let trans = transacts.filter(tran => tran.tipo_operacion === 2)
    let totSales = trans.map(sale => sale.cantidad * sale.valor_actual);
    return totSales;
}
 */





{/* <label htmlFor="txtPur" >Compras: </label>
<input type="text" name="txtPur" id="txtPur" value="" readOnly={true} />
<hr />

<label htmlFor="txtSales" >Ventas: </label>
<input type="text" name="txtSales" id="txtSales" value="" readOnly={true} />
<hr />
 */}