import React from 'react'
import { useEffect, useRef, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { currenciesSlice, getCurrencies } from '../../features/currenciesSlice';
import { useNavigate } from 'react-router-dom';
import Transactions from './Transactions';
import { addTransaction } from '../../features/transactionsSlice';

const CreateTransaction = () => {

    const urlCurrencies = 'https://crypto.develotion.com/monedas.php'
    const urlTranPost = 'https://crypto.develotion.com/transacciones.php'

    const dispatch = useDispatch();

    const navigate = useNavigate();

    const currencies = useSelector(state => state.currencies.currencies);
    const [currencyPrice, setCurrencyPrice] = useState(0);
    const [currency, setCurrency] = useState(0);
    const [tranType, setTranType] = useState(0);

    const quantity = useRef(null);

 
    useEffect(() => {

        if(localStorage.getItem('userId') === "" || localStorage.getItem('userId') === null){
            navigate("/");
        }

        fetch(urlCurrencies, {
            method: 'GET',
            headers: {
                'apikey': localStorage.getItem('apiKey'),
                'Content-Type': 'application/json; charset=UTF-8',
            },
        })
            .then(response => {
                if (response.status === 200) {
                  return response.json();
                } else {
                  return Promise.reject(response);
                }
              })
            .then(data => {
                dispatch(getCurrencies(data.monedas));
            })
            .catch((error) => alert(`Error: ${error.statusText}`));

    }, []);

    const getTransactionType = evt => {
        let tranTypeValue = evt.target.value;
        setTranType(tranTypeValue);
    }


    const handleChange = event => {
        let currencyVal = Number(event.target.value);
        setCurrency(currencyVal);
        const selectedCur = currencies.find(cur => cur.id == currencyVal);
        setCurrencyPrice(selectedCur.cotizacion);
    }



    const submitTransaction = () => {
        let apiKey = localStorage.getItem("apiKey");
        let userId = localStorage.getItem("userId");
        let quant = quantity.current.value;


        let tranObj = {
            "idUsuario": Number(userId),
            "tipoOperacion": Number(tranType),
            "moneda": currency,
            "cantidad": Number(quant),
            "valorActual": currencyPrice
        }

        fetch(urlTranPost, {
            method: 'POST',
            body: JSON.stringify(tranObj),
            headers: {
                'apikey': apiKey,
                'Content-Type': 'application/json',
            }
        })
            .then(response => {
                if(response.status === 200){
                    return response.json();
                } else {
                    return Promise.reject(response);
                }
            })
            .then((data) => {
                tranObj.id = data.idTransaccion;
                let objReFormat = {
                    'id': data.idTransaccion,
                    'usuarios_id': Number(userId),
                    'tipo_operacion': Number(tranType),
                    'moneda': currency,
                    'cantidad': Number(quant),
                    'valor_actual': currencyPrice
                }
                dispatch(addTransaction(objReFormat));
            })
            .catch((error) => alert('Error'));
    }

    return (
        <div>
            <h4> AGREGAR UNA TRANSACCION </h4>
            <label htmlFor="slcTransacType">Seleccione el Tipo de Operación: </label>
            <select onChange={getTransactionType} name="slcTransacType" id="idType">
                <option value=""> Seleccione tipo de operación </option>
                <option key="1" value="1"> Compra </option>
                <option key="2" value="2"> Venta </option>
            </select>
            <hr />
            <label htmlFor="slcCurrencies">Seleccione una Moneda: </label>
            <select onChange={handleChange} name="slcCurrencies" id="idCur">
                <option value=""> Seleccione una moneda </option>
                {currencies.map(option => (
                    <option key={option.id} value={option.id}> {option.nombre} </option>
                ))}
            </select>
            <hr />
            <label htmlFor="txtQuantity">Cantidad: </label>
            <input ref={quantity} type="text" name="txtQuantity" id="txtQuantity" />
            <hr />
            <label htmlFor="txtCurrentValue" >Cotizacion: </label>
            <input type="text" name="txtCurrentValue" id="txtCurrentValue" value={currencyPrice} readOnly={true} />
            <hr />

            <input type="button" value="Agregar Transacción" onClick={submitTransaction} />

        </div>
    )
}

export default CreateTransaction