import React from 'react'
import { Outlet, NavLink } from 'react-router-dom';

const Menu = () => {
  return (
    <div>
      <div>
          <hr/>
          


          <NavLink to="/">Login</NavLink> | 
          <NavLink to="/Dashboard/Transactions">Transacciones </NavLink> | 
          <NavLink to="/Dashboard/CreateTransaction">Agregar Transacción </NavLink> | 
          <NavLink to="/Dashboard/Graphs">Gráficas </NavLink> | 
          <NavLink to="/Dashboard/Investments">Inversiones </NavLink> | 
          <NavLink to="">Logout</NavLink>  

          

          <hr/>
      </div>
    
      <Outlet/>

    </div>
  )
}

export default Menu